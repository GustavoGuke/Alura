﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Frm_Principal_02
    Inherits System.Windows.Forms.Form

    'Descartar substituições de formulário para limpar a lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Exigido pelo Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'OBSERVAÇÃO: o procedimento a seguir é exigido pelo Windows Form Designer
    'Pode ser modificado usando o Windows Form Designer.  
    'Não o modifique usando o editor de códigos.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.Lbl_Principal_02 = New System.Windows.Forms.Label()
        Me.Lbl_Valor_Gabriela = New System.Windows.Forms.Label()
        Me.Txt_Valor_Gabriela = New System.Windows.Forms.TextBox()
        Me.Btm_Sacar_Gabriela = New System.Windows.Forms.Button()
        Me.Txt_Saldo_Gabriela = New System.Windows.Forms.TextBox()
        Me.Lbl_Saldo_Gabriela = New System.Windows.Forms.Label()
        Me.Txt_Resultado_Gabriela = New System.Windows.Forms.TextBox()
        Me.Lbl_Resultado_Gabriela = New System.Windows.Forms.Label()
        Me.Txt_SaldoAtual_Gabriela = New System.Windows.Forms.TextBox()
        Me.Lbl_SaldoAtual_Gabriela = New System.Windows.Forms.Label()
        Me.Lbl_BemVindo_Gabriela = New System.Windows.Forms.Label()
        Me.Btm_Depositar_Gabriela = New System.Windows.Forms.Button()
        Me.Txt_Extrato_Gabriela = New System.Windows.Forms.TextBox()
        Me.Grp_Gabriela = New System.Windows.Forms.GroupBox()
        Me.Btm_Transferir_Gabriela = New System.Windows.Forms.Button()
        Me.Grp_Bruno = New System.Windows.Forms.GroupBox()
        Me.Btm_Transferir_Bruno = New System.Windows.Forms.Button()
        Me.Lbl_BemVindo_Bruno = New System.Windows.Forms.Label()
        Me.Txt_Extrato_Bruno = New System.Windows.Forms.TextBox()
        Me.Lbl_Valor_Bruno = New System.Windows.Forms.Label()
        Me.Btm_Depositar_Bruno = New System.Windows.Forms.Button()
        Me.Txt_Valor_Bruno = New System.Windows.Forms.TextBox()
        Me.Btm_Sacar_Bruno = New System.Windows.Forms.Button()
        Me.Txt_SaldoAtual_Bruno = New System.Windows.Forms.TextBox()
        Me.Lbl_Saldo_Bruno = New System.Windows.Forms.Label()
        Me.Lbl_SaldoAtual_Bruno = New System.Windows.Forms.Label()
        Me.Txt_Saldo_Bruno = New System.Windows.Forms.TextBox()
        Me.Lbl_Resultado_Bruno = New System.Windows.Forms.Label()
        Me.Txt_Resultado_Bruno = New System.Windows.Forms.TextBox()
        Me.Lbl_Nome_Gabriela = New System.Windows.Forms.Label()
        Me.Txt_Nome_Gabriela = New System.Windows.Forms.TextBox()
        Me.Btm_Nome_Gabriela = New System.Windows.Forms.Button()
        Me.Btm_Nome_Bruno = New System.Windows.Forms.Button()
        Me.Txt_Nome_Bruno = New System.Windows.Forms.TextBox()
        Me.Lbl_Nome_Bruno = New System.Windows.Forms.Label()
        Me.Grp_Gabriela.SuspendLayout()
        Me.Grp_Bruno.SuspendLayout()
        Me.SuspendLayout()
        '
        'Lbl_Principal_02
        '
        Me.Lbl_Principal_02.AutoSize = True
        Me.Lbl_Principal_02.Location = New System.Drawing.Point(9, 9)
        Me.Lbl_Principal_02.Name = "Lbl_Principal_02"
        Me.Lbl_Principal_02.Size = New System.Drawing.Size(39, 13)
        Me.Lbl_Principal_02.TabIndex = 0
        Me.Lbl_Principal_02.Text = "Label1"
        '
        'Lbl_Valor_Gabriela
        '
        Me.Lbl_Valor_Gabriela.AutoSize = True
        Me.Lbl_Valor_Gabriela.Location = New System.Drawing.Point(16, 97)
        Me.Lbl_Valor_Gabriela.Name = "Lbl_Valor_Gabriela"
        Me.Lbl_Valor_Gabriela.Size = New System.Drawing.Size(39, 13)
        Me.Lbl_Valor_Gabriela.TabIndex = 1
        Me.Lbl_Valor_Gabriela.Text = "Label1"
        '
        'Txt_Valor_Gabriela
        '
        Me.Txt_Valor_Gabriela.Location = New System.Drawing.Point(19, 113)
        Me.Txt_Valor_Gabriela.Name = "Txt_Valor_Gabriela"
        Me.Txt_Valor_Gabriela.Size = New System.Drawing.Size(174, 20)
        Me.Txt_Valor_Gabriela.TabIndex = 2
        '
        'Btm_Sacar_Gabriela
        '
        Me.Btm_Sacar_Gabriela.Location = New System.Drawing.Point(19, 167)
        Me.Btm_Sacar_Gabriela.Name = "Btm_Sacar_Gabriela"
        Me.Btm_Sacar_Gabriela.Size = New System.Drawing.Size(174, 23)
        Me.Btm_Sacar_Gabriela.TabIndex = 3
        Me.Btm_Sacar_Gabriela.Text = "Button1"
        Me.Btm_Sacar_Gabriela.UseVisualStyleBackColor = True
        '
        'Txt_Saldo_Gabriela
        '
        Me.Txt_Saldo_Gabriela.Location = New System.Drawing.Point(19, 239)
        Me.Txt_Saldo_Gabriela.Name = "Txt_Saldo_Gabriela"
        Me.Txt_Saldo_Gabriela.Size = New System.Drawing.Size(174, 20)
        Me.Txt_Saldo_Gabriela.TabIndex = 5
        '
        'Lbl_Saldo_Gabriela
        '
        Me.Lbl_Saldo_Gabriela.AutoSize = True
        Me.Lbl_Saldo_Gabriela.Location = New System.Drawing.Point(16, 223)
        Me.Lbl_Saldo_Gabriela.Name = "Lbl_Saldo_Gabriela"
        Me.Lbl_Saldo_Gabriela.Size = New System.Drawing.Size(39, 13)
        Me.Lbl_Saldo_Gabriela.TabIndex = 4
        Me.Lbl_Saldo_Gabriela.Text = "Label1"
        '
        'Txt_Resultado_Gabriela
        '
        Me.Txt_Resultado_Gabriela.Location = New System.Drawing.Point(19, 285)
        Me.Txt_Resultado_Gabriela.Name = "Txt_Resultado_Gabriela"
        Me.Txt_Resultado_Gabriela.Size = New System.Drawing.Size(174, 20)
        Me.Txt_Resultado_Gabriela.TabIndex = 6
        '
        'Lbl_Resultado_Gabriela
        '
        Me.Lbl_Resultado_Gabriela.AutoSize = True
        Me.Lbl_Resultado_Gabriela.Location = New System.Drawing.Point(16, 269)
        Me.Lbl_Resultado_Gabriela.Name = "Lbl_Resultado_Gabriela"
        Me.Lbl_Resultado_Gabriela.Size = New System.Drawing.Size(39, 13)
        Me.Lbl_Resultado_Gabriela.TabIndex = 7
        Me.Lbl_Resultado_Gabriela.Text = "Label1"
        '
        'Txt_SaldoAtual_Gabriela
        '
        Me.Txt_SaldoAtual_Gabriela.Location = New System.Drawing.Point(19, 70)
        Me.Txt_SaldoAtual_Gabriela.Name = "Txt_SaldoAtual_Gabriela"
        Me.Txt_SaldoAtual_Gabriela.Size = New System.Drawing.Size(174, 20)
        Me.Txt_SaldoAtual_Gabriela.TabIndex = 9
        '
        'Lbl_SaldoAtual_Gabriela
        '
        Me.Lbl_SaldoAtual_Gabriela.AutoSize = True
        Me.Lbl_SaldoAtual_Gabriela.Location = New System.Drawing.Point(16, 54)
        Me.Lbl_SaldoAtual_Gabriela.Name = "Lbl_SaldoAtual_Gabriela"
        Me.Lbl_SaldoAtual_Gabriela.Size = New System.Drawing.Size(39, 13)
        Me.Lbl_SaldoAtual_Gabriela.TabIndex = 8
        Me.Lbl_SaldoAtual_Gabriela.Text = "Label1"
        '
        'Lbl_BemVindo_Gabriela
        '
        Me.Lbl_BemVindo_Gabriela.AutoSize = True
        Me.Lbl_BemVindo_Gabriela.Location = New System.Drawing.Point(16, 29)
        Me.Lbl_BemVindo_Gabriela.Name = "Lbl_BemVindo_Gabriela"
        Me.Lbl_BemVindo_Gabriela.Size = New System.Drawing.Size(39, 13)
        Me.Lbl_BemVindo_Gabriela.TabIndex = 10
        Me.Lbl_BemVindo_Gabriela.Text = "Label1"
        '
        'Btm_Depositar_Gabriela
        '
        Me.Btm_Depositar_Gabriela.Location = New System.Drawing.Point(19, 139)
        Me.Btm_Depositar_Gabriela.Name = "Btm_Depositar_Gabriela"
        Me.Btm_Depositar_Gabriela.Size = New System.Drawing.Size(174, 23)
        Me.Btm_Depositar_Gabriela.TabIndex = 11
        Me.Btm_Depositar_Gabriela.Text = "Button1"
        Me.Btm_Depositar_Gabriela.UseVisualStyleBackColor = True
        '
        'Txt_Extrato_Gabriela
        '
        Me.Txt_Extrato_Gabriela.Location = New System.Drawing.Point(211, 113)
        Me.Txt_Extrato_Gabriela.Multiline = True
        Me.Txt_Extrato_Gabriela.Name = "Txt_Extrato_Gabriela"
        Me.Txt_Extrato_Gabriela.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.Txt_Extrato_Gabriela.Size = New System.Drawing.Size(204, 192)
        Me.Txt_Extrato_Gabriela.TabIndex = 12
        '
        'Grp_Gabriela
        '
        Me.Grp_Gabriela.Controls.Add(Me.Btm_Nome_Gabriela)
        Me.Grp_Gabriela.Controls.Add(Me.Txt_Nome_Gabriela)
        Me.Grp_Gabriela.Controls.Add(Me.Lbl_Nome_Gabriela)
        Me.Grp_Gabriela.Controls.Add(Me.Btm_Transferir_Gabriela)
        Me.Grp_Gabriela.Controls.Add(Me.Lbl_BemVindo_Gabriela)
        Me.Grp_Gabriela.Controls.Add(Me.Txt_Extrato_Gabriela)
        Me.Grp_Gabriela.Controls.Add(Me.Lbl_Valor_Gabriela)
        Me.Grp_Gabriela.Controls.Add(Me.Btm_Depositar_Gabriela)
        Me.Grp_Gabriela.Controls.Add(Me.Txt_Valor_Gabriela)
        Me.Grp_Gabriela.Controls.Add(Me.Btm_Sacar_Gabriela)
        Me.Grp_Gabriela.Controls.Add(Me.Txt_SaldoAtual_Gabriela)
        Me.Grp_Gabriela.Controls.Add(Me.Lbl_Saldo_Gabriela)
        Me.Grp_Gabriela.Controls.Add(Me.Lbl_SaldoAtual_Gabriela)
        Me.Grp_Gabriela.Controls.Add(Me.Txt_Saldo_Gabriela)
        Me.Grp_Gabriela.Controls.Add(Me.Lbl_Resultado_Gabriela)
        Me.Grp_Gabriela.Controls.Add(Me.Txt_Resultado_Gabriela)
        Me.Grp_Gabriela.Location = New System.Drawing.Point(12, 42)
        Me.Grp_Gabriela.Name = "Grp_Gabriela"
        Me.Grp_Gabriela.Size = New System.Drawing.Size(428, 323)
        Me.Grp_Gabriela.TabIndex = 13
        Me.Grp_Gabriela.TabStop = False
        Me.Grp_Gabriela.Text = "GroupBox1"
        '
        'Btm_Transferir_Gabriela
        '
        Me.Btm_Transferir_Gabriela.Location = New System.Drawing.Point(19, 196)
        Me.Btm_Transferir_Gabriela.Name = "Btm_Transferir_Gabriela"
        Me.Btm_Transferir_Gabriela.Size = New System.Drawing.Size(174, 23)
        Me.Btm_Transferir_Gabriela.TabIndex = 13
        Me.Btm_Transferir_Gabriela.Text = "Button1"
        Me.Btm_Transferir_Gabriela.UseVisualStyleBackColor = True
        '
        'Grp_Bruno
        '
        Me.Grp_Bruno.Controls.Add(Me.Btm_Nome_Bruno)
        Me.Grp_Bruno.Controls.Add(Me.Txt_Nome_Bruno)
        Me.Grp_Bruno.Controls.Add(Me.Lbl_Nome_Bruno)
        Me.Grp_Bruno.Controls.Add(Me.Btm_Transferir_Bruno)
        Me.Grp_Bruno.Controls.Add(Me.Lbl_BemVindo_Bruno)
        Me.Grp_Bruno.Controls.Add(Me.Txt_Extrato_Bruno)
        Me.Grp_Bruno.Controls.Add(Me.Lbl_Valor_Bruno)
        Me.Grp_Bruno.Controls.Add(Me.Btm_Depositar_Bruno)
        Me.Grp_Bruno.Controls.Add(Me.Txt_Valor_Bruno)
        Me.Grp_Bruno.Controls.Add(Me.Btm_Sacar_Bruno)
        Me.Grp_Bruno.Controls.Add(Me.Txt_SaldoAtual_Bruno)
        Me.Grp_Bruno.Controls.Add(Me.Lbl_Saldo_Bruno)
        Me.Grp_Bruno.Controls.Add(Me.Lbl_SaldoAtual_Bruno)
        Me.Grp_Bruno.Controls.Add(Me.Txt_Saldo_Bruno)
        Me.Grp_Bruno.Controls.Add(Me.Lbl_Resultado_Bruno)
        Me.Grp_Bruno.Controls.Add(Me.Txt_Resultado_Bruno)
        Me.Grp_Bruno.Location = New System.Drawing.Point(446, 42)
        Me.Grp_Bruno.Name = "Grp_Bruno"
        Me.Grp_Bruno.Size = New System.Drawing.Size(428, 323)
        Me.Grp_Bruno.TabIndex = 14
        Me.Grp_Bruno.TabStop = False
        Me.Grp_Bruno.Text = "GroupBox1"
        '
        'Btm_Transferir_Bruno
        '
        Me.Btm_Transferir_Bruno.Location = New System.Drawing.Point(19, 196)
        Me.Btm_Transferir_Bruno.Name = "Btm_Transferir_Bruno"
        Me.Btm_Transferir_Bruno.Size = New System.Drawing.Size(174, 23)
        Me.Btm_Transferir_Bruno.TabIndex = 13
        Me.Btm_Transferir_Bruno.Text = "Button1"
        Me.Btm_Transferir_Bruno.UseVisualStyleBackColor = True
        '
        'Lbl_BemVindo_Bruno
        '
        Me.Lbl_BemVindo_Bruno.AutoSize = True
        Me.Lbl_BemVindo_Bruno.Location = New System.Drawing.Point(16, 29)
        Me.Lbl_BemVindo_Bruno.Name = "Lbl_BemVindo_Bruno"
        Me.Lbl_BemVindo_Bruno.Size = New System.Drawing.Size(39, 13)
        Me.Lbl_BemVindo_Bruno.TabIndex = 10
        Me.Lbl_BemVindo_Bruno.Text = "Label1"
        '
        'Txt_Extrato_Bruno
        '
        Me.Txt_Extrato_Bruno.Location = New System.Drawing.Point(211, 113)
        Me.Txt_Extrato_Bruno.Multiline = True
        Me.Txt_Extrato_Bruno.Name = "Txt_Extrato_Bruno"
        Me.Txt_Extrato_Bruno.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.Txt_Extrato_Bruno.Size = New System.Drawing.Size(204, 192)
        Me.Txt_Extrato_Bruno.TabIndex = 12
        '
        'Lbl_Valor_Bruno
        '
        Me.Lbl_Valor_Bruno.AutoSize = True
        Me.Lbl_Valor_Bruno.Location = New System.Drawing.Point(16, 97)
        Me.Lbl_Valor_Bruno.Name = "Lbl_Valor_Bruno"
        Me.Lbl_Valor_Bruno.Size = New System.Drawing.Size(39, 13)
        Me.Lbl_Valor_Bruno.TabIndex = 1
        Me.Lbl_Valor_Bruno.Text = "Label1"
        '
        'Btm_Depositar_Bruno
        '
        Me.Btm_Depositar_Bruno.Location = New System.Drawing.Point(19, 139)
        Me.Btm_Depositar_Bruno.Name = "Btm_Depositar_Bruno"
        Me.Btm_Depositar_Bruno.Size = New System.Drawing.Size(174, 23)
        Me.Btm_Depositar_Bruno.TabIndex = 11
        Me.Btm_Depositar_Bruno.Text = "Button1"
        Me.Btm_Depositar_Bruno.UseVisualStyleBackColor = True
        '
        'Txt_Valor_Bruno
        '
        Me.Txt_Valor_Bruno.Location = New System.Drawing.Point(19, 113)
        Me.Txt_Valor_Bruno.Name = "Txt_Valor_Bruno"
        Me.Txt_Valor_Bruno.Size = New System.Drawing.Size(174, 20)
        Me.Txt_Valor_Bruno.TabIndex = 2
        '
        'Btm_Sacar_Bruno
        '
        Me.Btm_Sacar_Bruno.Location = New System.Drawing.Point(19, 167)
        Me.Btm_Sacar_Bruno.Name = "Btm_Sacar_Bruno"
        Me.Btm_Sacar_Bruno.Size = New System.Drawing.Size(174, 23)
        Me.Btm_Sacar_Bruno.TabIndex = 3
        Me.Btm_Sacar_Bruno.Text = "Button1"
        Me.Btm_Sacar_Bruno.UseVisualStyleBackColor = True
        '
        'Txt_SaldoAtual_Bruno
        '
        Me.Txt_SaldoAtual_Bruno.Location = New System.Drawing.Point(19, 70)
        Me.Txt_SaldoAtual_Bruno.Name = "Txt_SaldoAtual_Bruno"
        Me.Txt_SaldoAtual_Bruno.Size = New System.Drawing.Size(174, 20)
        Me.Txt_SaldoAtual_Bruno.TabIndex = 9
        '
        'Lbl_Saldo_Bruno
        '
        Me.Lbl_Saldo_Bruno.AutoSize = True
        Me.Lbl_Saldo_Bruno.Location = New System.Drawing.Point(16, 223)
        Me.Lbl_Saldo_Bruno.Name = "Lbl_Saldo_Bruno"
        Me.Lbl_Saldo_Bruno.Size = New System.Drawing.Size(39, 13)
        Me.Lbl_Saldo_Bruno.TabIndex = 4
        Me.Lbl_Saldo_Bruno.Text = "Label1"
        '
        'Lbl_SaldoAtual_Bruno
        '
        Me.Lbl_SaldoAtual_Bruno.AutoSize = True
        Me.Lbl_SaldoAtual_Bruno.Location = New System.Drawing.Point(16, 54)
        Me.Lbl_SaldoAtual_Bruno.Name = "Lbl_SaldoAtual_Bruno"
        Me.Lbl_SaldoAtual_Bruno.Size = New System.Drawing.Size(39, 13)
        Me.Lbl_SaldoAtual_Bruno.TabIndex = 8
        Me.Lbl_SaldoAtual_Bruno.Text = "Label1"
        '
        'Txt_Saldo_Bruno
        '
        Me.Txt_Saldo_Bruno.Location = New System.Drawing.Point(19, 239)
        Me.Txt_Saldo_Bruno.Name = "Txt_Saldo_Bruno"
        Me.Txt_Saldo_Bruno.Size = New System.Drawing.Size(174, 20)
        Me.Txt_Saldo_Bruno.TabIndex = 5
        '
        'Lbl_Resultado_Bruno
        '
        Me.Lbl_Resultado_Bruno.AutoSize = True
        Me.Lbl_Resultado_Bruno.Location = New System.Drawing.Point(16, 269)
        Me.Lbl_Resultado_Bruno.Name = "Lbl_Resultado_Bruno"
        Me.Lbl_Resultado_Bruno.Size = New System.Drawing.Size(39, 13)
        Me.Lbl_Resultado_Bruno.TabIndex = 7
        Me.Lbl_Resultado_Bruno.Text = "Label1"
        '
        'Txt_Resultado_Bruno
        '
        Me.Txt_Resultado_Bruno.Location = New System.Drawing.Point(19, 285)
        Me.Txt_Resultado_Bruno.Name = "Txt_Resultado_Bruno"
        Me.Txt_Resultado_Bruno.Size = New System.Drawing.Size(174, 20)
        Me.Txt_Resultado_Bruno.TabIndex = 6
        '
        'Lbl_Nome_Gabriela
        '
        Me.Lbl_Nome_Gabriela.AutoSize = True
        Me.Lbl_Nome_Gabriela.Location = New System.Drawing.Point(208, 54)
        Me.Lbl_Nome_Gabriela.Name = "Lbl_Nome_Gabriela"
        Me.Lbl_Nome_Gabriela.Size = New System.Drawing.Size(39, 13)
        Me.Lbl_Nome_Gabriela.TabIndex = 14
        Me.Lbl_Nome_Gabriela.Text = "Label1"
        '
        'Txt_Nome_Gabriela
        '
        Me.Txt_Nome_Gabriela.Location = New System.Drawing.Point(211, 70)
        Me.Txt_Nome_Gabriela.Name = "Txt_Nome_Gabriela"
        Me.Txt_Nome_Gabriela.Size = New System.Drawing.Size(156, 20)
        Me.Txt_Nome_Gabriela.TabIndex = 15
        '
        'Btm_Nome_Gabriela
        '
        Me.Btm_Nome_Gabriela.Location = New System.Drawing.Point(374, 70)
        Me.Btm_Nome_Gabriela.Name = "Btm_Nome_Gabriela"
        Me.Btm_Nome_Gabriela.Size = New System.Drawing.Size(41, 23)
        Me.Btm_Nome_Gabriela.TabIndex = 16
        Me.Btm_Nome_Gabriela.Text = "Button1"
        Me.Btm_Nome_Gabriela.UseVisualStyleBackColor = True
        '
        'Btm_Nome_Bruno
        '
        Me.Btm_Nome_Bruno.Location = New System.Drawing.Point(374, 70)
        Me.Btm_Nome_Bruno.Name = "Btm_Nome_Bruno"
        Me.Btm_Nome_Bruno.Size = New System.Drawing.Size(41, 23)
        Me.Btm_Nome_Bruno.TabIndex = 19
        Me.Btm_Nome_Bruno.Text = "Button1"
        Me.Btm_Nome_Bruno.UseVisualStyleBackColor = True
        '
        'Txt_Nome_Bruno
        '
        Me.Txt_Nome_Bruno.Location = New System.Drawing.Point(211, 70)
        Me.Txt_Nome_Bruno.Name = "Txt_Nome_Bruno"
        Me.Txt_Nome_Bruno.Size = New System.Drawing.Size(156, 20)
        Me.Txt_Nome_Bruno.TabIndex = 18
        '
        'Lbl_Nome_Bruno
        '
        Me.Lbl_Nome_Bruno.AutoSize = True
        Me.Lbl_Nome_Bruno.Location = New System.Drawing.Point(208, 54)
        Me.Lbl_Nome_Bruno.Name = "Lbl_Nome_Bruno"
        Me.Lbl_Nome_Bruno.Size = New System.Drawing.Size(39, 13)
        Me.Lbl_Nome_Bruno.TabIndex = 17
        Me.Lbl_Nome_Bruno.Text = "Label1"
        '
        'Frm_Principal_02
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(885, 377)
        Me.Controls.Add(Me.Grp_Bruno)
        Me.Controls.Add(Me.Grp_Gabriela)
        Me.Controls.Add(Me.Lbl_Principal_02)
        Me.Name = "Frm_Principal_02"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Frm_Principal_02"
        Me.Grp_Gabriela.ResumeLayout(False)
        Me.Grp_Gabriela.PerformLayout()
        Me.Grp_Bruno.ResumeLayout(False)
        Me.Grp_Bruno.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Lbl_Principal_02 As Label
    Friend WithEvents Lbl_Valor_Gabriela As Label
    Friend WithEvents Txt_Valor_Gabriela As TextBox
    Friend WithEvents Btm_Sacar_Gabriela As Button
    Friend WithEvents Txt_Saldo_Gabriela As TextBox
    Friend WithEvents Lbl_Saldo_Gabriela As Label
    Friend WithEvents Txt_Resultado_Gabriela As TextBox
    Friend WithEvents Lbl_Resultado_Gabriela As Label
    Friend WithEvents Txt_SaldoAtual_Gabriela As TextBox
    Friend WithEvents Lbl_SaldoAtual_Gabriela As Label
    Friend WithEvents Lbl_BemVindo_Gabriela As Label
    Friend WithEvents Btm_Depositar_Gabriela As Button
    Friend WithEvents Txt_Extrato_Gabriela As TextBox
    Friend WithEvents Grp_Gabriela As GroupBox
    Friend WithEvents Grp_Bruno As GroupBox
    Friend WithEvents Lbl_BemVindo_Bruno As Label
    Friend WithEvents Txt_Extrato_Bruno As TextBox
    Friend WithEvents Lbl_Valor_Bruno As Label
    Friend WithEvents Btm_Depositar_Bruno As Button
    Friend WithEvents Txt_Valor_Bruno As TextBox
    Friend WithEvents Btm_Sacar_Bruno As Button
    Friend WithEvents Txt_SaldoAtual_Bruno As TextBox
    Friend WithEvents Lbl_Saldo_Bruno As Label
    Friend WithEvents Lbl_SaldoAtual_Bruno As Label
    Friend WithEvents Txt_Saldo_Bruno As TextBox
    Friend WithEvents Lbl_Resultado_Bruno As Label
    Friend WithEvents Txt_Resultado_Bruno As TextBox
    Friend WithEvents Btm_Transferir_Gabriela As Button
    Friend WithEvents Btm_Transferir_Bruno As Button
    Friend WithEvents Btm_Nome_Gabriela As Button
    Friend WithEvents Txt_Nome_Gabriela As TextBox
    Friend WithEvents Lbl_Nome_Gabriela As Label
    Friend WithEvents Btm_Nome_Bruno As Button
    Friend WithEvents Txt_Nome_Bruno As TextBox
    Friend WithEvents Lbl_Nome_Bruno As Label
End Class