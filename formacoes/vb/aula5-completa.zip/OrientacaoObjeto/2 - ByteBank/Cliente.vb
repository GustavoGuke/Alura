﻿

Namespace ByteBank

    Public Class Cliente

        Public Nome As String
        Public CPF As String
        Public Profissao As String
        Public Cidade As String

    End Class

End Namespace



