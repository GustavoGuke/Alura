New-Alias rename rename-item
New-Alias d get-childitem
echo "Oi, Guilherme"