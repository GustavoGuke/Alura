<?php

$telefones = ['(24) 99999 - 9999 ', ' (21) 99999 - 9999', '(24) 2222 - 2222'];

echo implode(array: $telefones, separator: ', ') . PHP_EOL;
