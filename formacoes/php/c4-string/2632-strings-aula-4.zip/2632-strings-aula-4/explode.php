<?php

$array = '1 2 3 4';

var_dump(explode(' ', $array, 2));