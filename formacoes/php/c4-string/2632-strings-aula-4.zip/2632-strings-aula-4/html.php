<?php

$nome = 'cam" /> <script>alert("teste");</script>';
?>
<input type="text" name="<?php echo htmlspecialchars($nome); ?>" />
