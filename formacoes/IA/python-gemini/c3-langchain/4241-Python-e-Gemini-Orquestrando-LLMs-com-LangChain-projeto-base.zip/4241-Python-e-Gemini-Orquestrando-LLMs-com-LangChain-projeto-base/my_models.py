GEMINI_PRO = "gemini-1.5-pro"
GEMINI_FLASH = "gemini-1.5-flash"
MARITACA_SABIA = "sabia-3"