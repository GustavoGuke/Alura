import styles from './spinner.module.css'

export const Spinner = () => {
    return (<span className={styles.loader}></span>)
}