export const ArrowFoward = () => {
    return <svg width="14" height="13" viewBox="0 0 14 13" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M7 0.488281L13.0117 6.5L7 12.5117L5.94531 11.457L10.1289 7.23828H0.988281V5.76172H10.1289L5.94531 1.54297L7 0.488281Z" fill="#132E35" />
    </svg>

}