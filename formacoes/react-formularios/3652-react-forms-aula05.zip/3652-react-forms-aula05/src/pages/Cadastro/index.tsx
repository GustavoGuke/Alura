import { Logotipo } from "../../components";
import CadastroPessoal from "./CadastroPessoal";
export default function Cadastro() {
  return (
    <>
      <Logotipo />
      <CadastroPessoal />
    </>
  );
}
