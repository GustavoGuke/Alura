import CadastroPessoal from "./CadastroPessoal";
import { Logotipo } from "../../components";
export default function Cadastro() {
  return (
    <>
      <Logotipo />
      <CadastroPessoal />
    </>
  );
}
