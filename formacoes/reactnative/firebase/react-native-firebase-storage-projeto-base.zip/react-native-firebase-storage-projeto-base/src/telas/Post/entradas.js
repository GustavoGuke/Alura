export const entradas = [
  {
    id: '1',
    name: 'titulo',
    label: 'Título'
  },
  {
    id: '2',
    name: 'fonte',
    label: 'Fonte',
  },
  {
    id: '3',
    name: 'descricao',
    label: 'Descrição',
    multiline: true,
  },
]