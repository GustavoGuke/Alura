import React, { useEffect, useState } from 'react';
import AppNavigation from './src/navigation/AppNavigation';


export default function App() {

  return (
      <AppNavigation />
  );
}
