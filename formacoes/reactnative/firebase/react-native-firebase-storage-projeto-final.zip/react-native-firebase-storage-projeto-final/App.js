import Rotas from "./src/rotas";

export default function App() {
  return (
    <Rotas />
  );
}