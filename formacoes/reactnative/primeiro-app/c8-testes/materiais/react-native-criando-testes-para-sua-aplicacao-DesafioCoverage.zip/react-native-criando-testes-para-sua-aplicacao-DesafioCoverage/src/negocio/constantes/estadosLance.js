export const INVALIDO = "Lance inválido, digite um valor como: \"100\" ou \"99,99\"";
export const MENOR_OU_IGUAL_AOS_LANCES = "Lance menor que o maior lance já realizado";
export const MENOR_QUE_VALOR_INICIAL = "Lance menor que o valor inicial";
export const VALIDO = "Lance válido";
export const NAO_ENVIADO = "Lance não enviado, tente novamente";
export const ENVIADO = "Lance enviado com sucesso";