import React from 'react';
import Rotas from './src/rotas';

export default function App() {
  return (
    <Rotas />
  );
}
