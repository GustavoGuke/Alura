const tema = {
  fundo: '#051933',
  titulo: '#FFFFFF',
  texto: '#FFFFFF',
  branco: '#FFFFFF',
  preto: '#000000',
  cinza: '#093245',
  ultimosVistos: '#093245',
  botao: '#A3FEBF',
  input: '#FFFFFF',
}

export { tema };