import { StyleSheet } from "react-native";

export default StyleSheet.create({
  linearGradient: {
    flex: 1,
  },
  image: {
    flex: 1
  }
});