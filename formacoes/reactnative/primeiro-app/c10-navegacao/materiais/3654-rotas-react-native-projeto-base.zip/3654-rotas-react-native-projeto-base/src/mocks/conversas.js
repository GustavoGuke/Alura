const conversas = [
    {
        nome: "Maria",
        mensagem: "Olá, tudo bem?",
    },
    {
        nome: "João",
        mensagem: "Você quer saber mais sobre o Dunga?",
    },
    {
        nome: "Pedro",
        mensagem: "Me interessei muito por ele",
    }
]

export default conversas;