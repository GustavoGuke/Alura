import produtores from "../mocks/produtores";
import textos from "../mocks/textos";

export const carregaProdutores = () => {
    return produtores;
}

export const carregaTextos = () => {
    return textos;
}
